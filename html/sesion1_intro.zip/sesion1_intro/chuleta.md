# Chuleta

- extensiones: 
  - live server
  - prettier
- html
- head
- body
- title
- meta
- h1 - h6
- p
- strong
- em
- ol
- ul
- li
- ld
- td
- dd
- a
- target="_blank"
  